

/**
 *  This class is the main class of the "World of Zuul" application. 
 *  "World of Zuul" is a very simple, text based adventure game.  Users 
 *  can walk around some scenery. That's all. It should really be extended 
 *  to make it more interesting!
 * 
 *  To play this game, create an instance of this class and call the "play"
 *  method.
 * 
 *  This main class creates and initialises all the others: it creates all
 *  rooms, creates the parser and starts the game.  It also evaluates and
 *  executes the commands that the parser returns.
 * 
 * @author  Michael Kölling and David J. Barnes
 * @version 2011.08.08
 */

public class Game 
{
    private Parser parser;
    private ParserWithFileInput parserWithFileInput;
    private Bar currentBar;
    
    
        
    /**
     * Create the game and initialise its internal map.
     */
    public Game() 
    {
        createRooms();
        parser = new Parser();
        parserWithFileInput = new ParserWithFileInput();
      
        
    }

    /**
     * Create all the rooms and link their exits together.
     */
    private void createRooms()
    {
        Bar Arch, Aftermath, BlueSky, Bourbon, Subway, Stonewalls, Cloud, OTR, Whiskey, Sandbar, Bagel, Coppercreek, Pizza, BoarsHead, 
        CornerofClaytonandCollege, CornerofJacksonandBroad, CornerofJacksonandClayton, CornerofWashingtonandCollege, 
        CornerofWashingtonandJackson, Home;
      
        // create the rooms
        Arch = new Bar("Starting at the arch");
        Aftermath = new Bar("in Aftermath");
        BlueSky = new Bar("in BlueSky");
        Bourbon = new Bar("in Bourbon");
        Subway = new Bar("in Subway");
        Stonewalls = new Bar("in Stonewalls");
        Cloud = new Bar("in Cloud");
        OTR = new Bar("in OTR");
        Whiskey = new Bar("in Whiskey");
        Sandbar = new Bar("in Sandbar");
        Bagel = new Bar("in Athens Bagel Co.");
        Coppercreek = new Bar("in Coppercreek");
        Pizza = new Bar("in Little Italy");
        BoarsHead = new Bar("are in Boars Head");
        Home = new Bar("AT HOME");
        CornerofClaytonandCollege = new Bar("at the corner of Clayton and College");
        CornerofJacksonandBroad = new Bar("at the corner of Jackson and Broad");
        CornerofJacksonandClayton = new Bar("at the corner of Jackson and Clayton");
        CornerofWashingtonandCollege = new Bar("at the corner of Washington and College");
        CornerofWashingtonandJackson = new Bar("at the corner of Washington and Jackson");
        
        // initialise room exits
        Arch.setExit("north", Subway);
        Arch.setExit("east", BlueSky);
        Arch.setExit("west", Aftermath);
        
        Aftermath.setExit("east", Arch);
        
        BlueSky.setExit("west", Arch);
        BlueSky.setExit("east", CornerofJacksonandBroad);
        
        CornerofJacksonandBroad.setExit("east", Bourbon);
        CornerofJacksonandBroad.setExit("north", Stonewalls);
        
        Bourbon.setExit("west", CornerofJacksonandBroad);
        
        Stonewalls.setExit("north", CornerofJacksonandClayton);
        Stonewalls.setExit("south", CornerofJacksonandBroad);
        
        Subway.setExit("south", Arch);
        Subway.setExit("north", CornerofClaytonandCollege);
        
        CornerofJacksonandClayton.setExit("south", Stonewalls);
        CornerofJacksonandClayton.setExit("north", Bagel);
        CornerofJacksonandClayton.setExit("east", Whiskey);
        CornerofJacksonandClayton.setExit("west", OTR);
        
        OTR.setExit("east", CornerofJacksonandClayton);
        OTR.setExit("west", CornerofClaytonandCollege);
        
        Whiskey.setExit("west", CornerofJacksonandClayton);
        
        CornerofClaytonandCollege.setExit("east", OTR);
        CornerofClaytonandCollege.setExit("west", Cloud);
        CornerofClaytonandCollege.setExit("north", Sandbar);
        CornerofClaytonandCollege.setExit("south", Subway);
        
        Cloud.setExit("east", CornerofClaytonandCollege);
        
        Sandbar.setExit("south", CornerofClaytonandCollege);
        Sandbar.setExit("north", CornerofWashingtonandCollege);
        
        CornerofWashingtonandCollege.setExit("south", Sandbar);
        CornerofWashingtonandCollege.setExit("east", Pizza);
        CornerofWashingtonandCollege.setExit("west", Coppercreek);
        CornerofWashingtonandCollege.setExit("north", Home);
        
        Coppercreek.setExit("east", CornerofWashingtonandCollege);
        
        Pizza.setExit("west", CornerofWashingtonandCollege);
        Pizza.setExit("east", CornerofWashingtonandJackson);
        
        CornerofWashingtonandJackson.setExit("west", Pizza);
        CornerofWashingtonandJackson.setExit("east", BoarsHead);
        CornerofWashingtonandJackson.setExit("south", Bagel);
        CornerofWashingtonandJackson.setExit("north", Home);
        
        BoarsHead.setExit("west", CornerofWashingtonandJackson);
        
        Home.setExit("south", CornerofWashingtonandCollege);
        
        Bagel.setExit("north", CornerofWashingtonandJackson);
        Bagel.setExit("south", CornerofJacksonandClayton);
        
        CornerofJacksonandBroad.setExit("east", Bourbon);
        CornerofJacksonandBroad.setExit("west", BlueSky);
        CornerofJacksonandBroad.setExit("north", Stonewalls);
        

        currentBar = Arch;  // start game outside
    }

    /**
     *  Main play routine.  Loops until end of play.
     */
    public void play() 
    {            
        printWelcome();

        // Enter the main command loop.  Here we repeatedly read commands and
        // execute them until the game is over.
                
        boolean finished = false;
        while (! finished) {
            Command command = parser.getCommand();
            finished = processCommand(command);
            
         
        }
            
 
        System.out.println("Thank you for playing.  Good bye.");
    }
   
    
    public void playWithFileInput() 
    {            
        printWelcome();
        // Enter the main command loop.  Here we repeatedly read commands and
        // execute them until the game is over.
                
        boolean finished = false;
        while (! finished) {
            Command command = parserWithFileInput.getCommand();
            finished = processCommand(command);
        }
        System.out.println("Thank you for playing.  Good bye.");
    }
    /**
     * Print out the opening message for the player.
     */
    private void printWelcome()
    {
        System.out.println();
        System.out.println("Welcome to Downtown Athens!");
        System.out.println("During a night in Athens, you never know where you might end up.");
        System.out.println("Type 'help' if you need help.");
        System.out.println();
        System.out.println(currentBar.getLongDescription());
    }

    /**
     * Given a command, process (that is: execute) the command.
     * @param command The command to be processed.
     * @return true If the command ends the game, false otherwise.
     */
    private boolean processCommand(Command command) 
    {
        boolean wantToQuit = false;

        if(command.isUnknown()) {
            System.out.println("I don't know what you mean...");
            return false;
        }

        String commandWord = command.getCommandWord();
        if (commandWord.equals("help")) {
            printHelp();
        }
        else if (commandWord.equals("go")) {
            goRoom(command);
        }
        else if (commandWord.equals("quit")) {
            wantToQuit = quit(command);
        }
        // else command not recognised.
        return wantToQuit;
    }

    // implementations of user commands:

    /**
     * Print out some help information.
     * Here we print some stupid, cryptic message and a list of the 
     * command words.
     */
    private void printHelp() 
    {
        System.out.println("You are lost. You are alone. You wander");
        System.out.println("around Athens.");
        System.out.println();
        System.out.println("Your command words are:");
        parser.showCommands();
    }

    /** 
     * Try to in to one direction. If there is an exit, enter the new
     * room, otherwise print an error message.
     */
    
    // We are having issues with the drink method. No syntax errors are present, but we do encounter a null pointer exception. The issue may lie somewhere in the fact that drink is a 
    //bar object. We probably have to do some work with all the classes and make a player class.
    private void goRoom(Command command) 
    {
        if(!command.hasSecondWord()) {
            // if there is no second word, we don't know where to go...
            System.out.println("Go where?");
            return;
        }
        String direction = command.getSecondWord();
        // Try to leave current room.
        Bar nextBar = currentBar.getExit(direction);

        if (nextBar == null) {
            System.out.println("There is no bar!");
        }
        else {
            currentBar = nextBar;
            currentBar.getDrink();
            currentBar.getAlcoholContent();
            System.out.println("Your alchol content is " + "" + currentBar.getAlcoholContent());
            System.out.println(currentBar.getLongDescription());
            
       }
  
    }

    /** 
     * "Quit" was entered. Check the rest of the command to see
     * whether we really quit the game.
     * @return true, if this command quits the game, false otherwise.
     */
    private boolean quit(Command command) 
    {
        if(command.hasSecondWord()) {
            System.out.println("Quit what?");
            return false;
        }
        else {
            return true;  // signal that we want to quit
        }
    }
}
