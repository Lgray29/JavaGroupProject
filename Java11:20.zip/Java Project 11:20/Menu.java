import java.util.HashMap;
import java.util.Random;

/**
 * Write a description of class Drink here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Menu
{
    private HashMap<Integer,String> drinks;
    private Random randomGenerator;
    private int index;

    /**
     * Constructor for objects of class Drink
     */
    public Menu()
    {
        drinks = new HashMap<Integer,String>();
        randomGenerator = new Random();
       setMenu();
    }
    
    /**
     * Increases the increment for the number of drinks consumed once you enter
     * a bar, decreases the increment for number of drinks consumed if you enter a 
     * restaurant
     */
    
    public void increment()
    {
        int value = 0;
        value = value + 1;
    }
    
    public void setMenu()
    {
       drinks.put(1,"Gin and Tonic");
       drinks.put(1,"Gin and Tonic");
       drinks.put(2,"Gin and Tonic");
       drinks.put(3,"Gin and Tonic");
       drinks.put(4,"Gin and Tonic");
       drinks.put(3,"Gin and Tonic");
       drinks.put(5,"Gin and Tonic");
       
        
        
    }
    
    
    
    public String pickRandomDrink()
    {
        index = randomGenerator.nextInt(5);
        return drinks.get(index);
    }
    
    public int alcoholContent()
    {
        return index;
        
    }
    
}
